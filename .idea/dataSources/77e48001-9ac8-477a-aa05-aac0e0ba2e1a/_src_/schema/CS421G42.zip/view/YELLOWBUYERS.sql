CREATE VIEW YellowBuyers (firstname, lastname, modelname, dateofcartcreation)
  AS SELECT C.firstname, C.lastname, D.modelname, S.datecreated
  FROM CUSTOMER C, SHOPPINGCART S, CARTDETAILS D, ORDER O
  WHERE C.email = S.customeremail and S.CARTID = D.CARTID
        and D.CARTID = O.CARTID and O.ordertype = 'PURCHASE'
        and D.color = 'YELLOW'